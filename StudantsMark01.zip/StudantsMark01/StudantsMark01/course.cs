﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudantsMark01
{
    public partial class course : Form
    {
       
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);

        String sql = "select IDClassRooms,NameClassRooms from ClassRooms";


        public SqlDataReader dr;
        public course()
        {
            InitializeComponent();
        }

        private void course_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.course' table. You can move, or remove it, as needed.
            
            SqlDataAdapter da = new SqlDataAdapter(sql , con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com1.DisplayMember = "NameClassRooms";
            com1.ValueMember = "IDClassRooms";
            com1.DataSource = dt;
                 
            // ssa();
        }


        
        public void lodacourse()
        {
         //   this.courseTableAdapter.Fill(this.database1DataSet.course);
            String sql1 = " select * from course WHERE IDClass like N'%" + com1.SelectedValue + "%'    ";
            SqlDataAdapter sda = new SqlDataAdapter(sql1, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].HeaderText = "اسم المادة";
            dataGridView1.Columns[2].HeaderText = "القيمة الصغرى للعلامة";
            dataGridView1.Columns[3].HeaderText = "القيمة العظمى للعلامة";
            dataGridView1.Columns[4].Visible = false;
        }



        public void ssa()
        {
            com1.Items.Clear();
            DataTable dt = new DataTable("NameClassRooms");
            con.Open();
            SqlCommand cmd = new SqlCommand("select IDClassRooms,NameClassRooms from ClassRooms", con);
            dr = cmd.ExecuteReader();
            dt.Load(dr);
            com1.DisplayMember = "NameClassRooms";
            com1.ValueMember = "IDClassRooms";
            com1.DataSource = dt;
            con.Close();
           
        }


        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddCourse addept = new AddCourse(this);
            addept.TxTNameClass.Text = com1.Text;
              addept.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
              EditCourse edept = new EditCourse(this);
            edept.t1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            edept.t2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            edept.t3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            edept.t4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            edept.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل تريد حذف هذا السجل", "Remove Row", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string ssa = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                string exesql = "Delete from course where CId='" + ssa + "'";
                SqlCommand ss = new SqlCommand(exesql, con);
                con.Open();
                ss.ExecuteNonQuery();
                con.Close();
                lodacourse();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lodacourse();
                 }
    }
}
