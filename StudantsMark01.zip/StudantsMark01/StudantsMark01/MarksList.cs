﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudantsMark01
{
    public partial class MarksList : Form
    {
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);     

        public MarksList()
        {
            InitializeComponent();
        }

        private void MarksList_Load(object sender, EventArgs e)
        {
            loadmark();
            LoadGrade();
            LoadClassRoom();
            LoadCourse();
            LoadStudent();
        }

        public void LoadGrade()
        {
            com5.Items.Clear();
            SqlDataAdapter da = new SqlDataAdapter("select * from Grades", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com5.DisplayMember = "NameGrade";
            com5.ValueMember = "IdGrade";
            com5.DataSource = dt;
            com5.Text = "";

        }


        public void LoadClassRoom()
        {
            com4.Items.Clear();
            SqlDataAdapter da = new SqlDataAdapter("select * from ClassRooms", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com4.DisplayMember = "NameClassRooms";
            com4.ValueMember = "IDClassRooms";
            com4.DataSource = dt;
            com4.Text = "";


        }

        public void LoadCourse()
        {
            com3.Items.Clear();
            String sql1 = " select * from course";
            SqlDataAdapter da = new SqlDataAdapter(sql1, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com3.DisplayMember = "CName";
            com3.ValueMember = "CId";
            com3.DataSource = dt;
            com3.Text = "";
        }


        public void LoadStudent()
        {
            com1.Items.Clear();
            SqlDataAdapter da = new SqlDataAdapter("select * from student", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com1.DisplayMember = "stname";
            com1.ValueMember = "stide";
            com1.DataSource = dt;
            com1.Text = "";


        }


        public void loadmark()
        {

            String sql = "select NameStudant , NameCourse , Mark , MarkState from Marks";
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataTable dts = new DataTable();
            sda.Fill(dts);
            dataGridView1.DataSource = dts;


            dataGridView1.Columns[0].HeaderText = "اسم الطالب";
            dataGridView1.Columns[1].HeaderText = "المادة";
            dataGridView1.Columns[2].HeaderText = "العلامة الكلية";
            dataGridView1.Columns[3].HeaderText = "الحالة";
     }


        private void button1_Click(object sender, EventArgs e)

        {
            String sql = " select NameStudant , NameCourse , Mark , MarkState from Marks WHERE MarkState like N'%" + com2.Text + "%' AND NameCourse like N'%" + com3.Text + "%' AND NameStudant like N'%" + com1.Text + "%'  AND NameClass like N'%" + com4.Text + "%' AND NameGrade like N'%" + com5.Text + "%'   ";
               SqlDataAdapter sda = new SqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loadmark();

        }

      

    
/*
        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            String sql = " select MarkState , Mark , NameCourse , NameStudant from Marks WHERE NameStudant like N'%{0}%'  ";
           // String sql = " select MarkState , Mark , NameCourse , NameStudant from Marks WHERE NameStudant = N'{0}'  ";
            sql = string.Format(sql, textBox1.Text);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

        }

 * */
       

      
    }
}