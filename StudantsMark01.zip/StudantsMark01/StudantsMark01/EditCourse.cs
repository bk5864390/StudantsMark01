﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudantsMark01
{
    public partial class EditCourse : Form
    {
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);

        course dept;
        public EditCourse(course cdept)
        {
            InitializeComponent();
            this.dept = cdept;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string exesql = " update course set CName =N'" + t2.Text + "', MinMark  = '" + t3.Text + "' , MaxMark  = '" + t4.Text + "' where CId='" + t1.Text + "'";
                SqlCommand ss = new SqlCommand(exesql, con);
                con.Open();
                ss.ExecuteNonQuery();
                dept.lodacourse();
                this.Close();
                con.Close();
            }
            catch (Exception ex){
                ex.ToString();
            }
        }

        private void EditCourse_Load(object sender, EventArgs e)
        {

        }
    }
}
