﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace StudantsMark01
{
    public partial class students : Form
    {

        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);

        public students()
        {
            InitializeComponent();
        }

        private void students_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.database1DataSet.student);

            SqlDataAdapter da = new SqlDataAdapter("select IDClassRooms,NameClassRooms from ClassRooms", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com1.DisplayMember = "NameClassRooms";
            com1.ValueMember = "IDClassRooms";
            com1.DataSource = dt;
                 

        }

        

        public void lodastudent() {

            String sql1 = " select * from student WHERE IDClass like N'%" + com1.SelectedValue + "%' ";
            SqlDataAdapter sda = new SqlDataAdapter(sql1, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

            dataGridView1.Columns[0].HeaderText = "رقم الطالب";
            dataGridView1.Columns[1].HeaderText = "اسم الطالب";
            dataGridView1.Columns[2].HeaderText = "العنوان";
            dataGridView1.Columns[3].HeaderText = "الجنس";
        }
      

        private void button4_Click(object sender, EventArgs e)
        {
            
             this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            AddStudant1 addstd = new AddStudant1(this);
            addstd.Show();
        }

        private void button2_Click(object sender, EventArgs e)   
        {
            EditStudent edstd = new EditStudent(this);
            edstd.t1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            edstd.t2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            edstd.com1.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
           edstd.Show();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       
           

        private void button3_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("هل تريد حذف هذا الطالب", "Remove Row", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string ssa = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                string exesql = "Delete from student where stide='" + ssa + "'";
                SqlCommand ss = new SqlCommand(exesql, con);
                con.Open();
                ss.ExecuteNonQuery();
                con.Close();
                lodastudent();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lodastudent();
        }
    }
}
