﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudantsMark01
{
    public partial class EditStudent : Form
    {

        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);

        students std01;
        public EditStudent(students std02)
        {
            InitializeComponent();
            this.std01 = std02;

        }

        
        private void EditStudent_Load(object sender, EventArgs e)
        {

            try
             {
                 string sql = " select ctname from city ";
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    com1.Items.Add(dr["ctname"].ToString());
                }

             }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                con.Close();
            }
        }

       
        

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string exesql = " update student set stname =N'" + t2.Text + "', stadd  = '" + com1.Text + "' where stide='" + t1.Text + "'";
            SqlCommand ss = new SqlCommand(exesql, con);
            con.Open();
            ss.ExecuteNonQuery();
            std01.lodastudent();
            this.Close();
            con.Close();
        }

    }
}
