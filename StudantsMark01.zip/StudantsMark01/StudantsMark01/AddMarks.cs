﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudantsMark01
{
    public partial class AddMarks : Form
    {
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);
        String state = "";
        String totalmark="";
        int a1, b1, c1, sum;

        public AddMarks()
        {
            InitializeComponent();
        }

        private void AddMarks_Load(object sender, EventArgs e)
        {
           
            LoadGrade();
            LoadClassRoom();
           
        }

        public void LoadGrade() {
            SqlDataAdapter da = new SqlDataAdapter("select NameGrade from Grades", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com3.DisplayMember = "NameGrade";
            com3.ValueMember = "IdGrade";
            com3.DataSource = dt;
                 
        }

      
        public void LoadClassRoom()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from ClassRooms", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com4.DisplayMember = "NameClassRooms";
            com4.ValueMember = "IDClassRooms";
            com4.DataSource = dt;

        }

        public void LoadCourse()
        {
            String sql1 = " select * from course WHERE IDClass like N'%" + com4.SelectedValue + "%'   ";
            SqlDataAdapter da = new SqlDataAdapter(sql1, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com2.DisplayMember = "CName";
            com2.ValueMember = "CId";
            com2.DataSource = dt;
        }

      
        public void LoadStudent()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from student where IDClass like N'%" + com4.SelectedValue + "%'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com1.DisplayMember = "stname";
            com1.ValueMember = "stide";
            com1.DataSource = dt;

        }
     

        public void LoadMarksGV() {
          //String sql = " select * from Marks WHERE NameClass like N'%" + com4.Text + "%' AND NameGrade like N'%" + com3.Text + "%'   ";
            String sql = " select NameStudant,NameCourse,NameClass,NameGrade,midtermexam,asepexam,finalexem,Mark,MarkState from Marks WHERE NameClass like N'%" + com4.Text + "%' AND NameGrade like N'%" + com3.Text + "%'   ";
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
          
            dataGridView1.Columns[0].HeaderText = "اسم الطالب";
            dataGridView1.Columns[1].HeaderText = "المادة";
            dataGridView1.Columns[2].HeaderText = "الصف";
            dataGridView1.Columns[3].HeaderText = "العام والفصل الدراسي";
            dataGridView1.Columns[4].HeaderText = "علامة النصفي";
            dataGridView1.Columns[5].HeaderText = "علامة اعمال الفصل";
            dataGridView1.Columns[6].HeaderText = "علامة النهائي";
            dataGridView1.Columns[7].HeaderText = " العلامة الكلية";
            dataGridView1.Columns[8].HeaderText = "الحالة";

            dataGridView1.Columns[2].Width = 120;
            dataGridView1.Columns[3].Width = 125;

          
        }

        private void com1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label9.Text = com1.Text;
        }

        private void com2_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Text = com2.Text;   
        }
   
        public void loadoumark()
        {

           
            try
            {
                sum = a1 + b1 + c1;
                if (sum > 0)
                
                label7.Text =  sum.ToString();
                  else 
                    label7.Text = "ادخل علامات ليظهر المجموع";

                
                if (sum >= 50)
                    label11.Text = "ناجح";
                else if (sum <= 49)
                    label11.Text = "راسب";

                if (string.IsNullOrEmpty(t1.Text) && string.IsNullOrEmpty(t2.Text) && string.IsNullOrEmpty(t3.Text))
                {
                    label11.Text = null;
                }

                state = label11.Text;
                totalmark = label7.Text;

            }
            catch (Exception ex){
                ex.ToString();

            }
        }


        private void t1_TextChanged(object sender, EventArgs e)
        {
            int.TryParse(t1.Text, out a1);
            loadoumark();
            /*
              if (!string.IsNullOrEmpty(t1.Text) && !string.IsNullOrEmpty(t2.Text) && !string.IsNullOrEmpty(t3.Text))
                label7.Text = (Convert.ToInt32(t1.Text) + Convert.ToInt32(t2.Text) + Convert.ToInt32(t3.Text)).ToString();
            else
            {
                label7.Text = null;
            }
             */
        }



        private void t2_TextChanged_1(object sender, EventArgs e)
        {
            int.TryParse(t2.Text, out b1);

            loadoumark();
            /*
              if (!string.IsNullOrEmpty(t1.Text) && !string.IsNullOrEmpty(t2.Text) && !string.IsNullOrEmpty(t3.Text))
                label7.Text = (Convert.ToInt32(t1.Text) + Convert.ToInt32(t2.Text) + Convert.ToInt32(t3.Text)).ToString();
            else
            {
                label7.Text = null;
            }
             */
        }

        private void t3_TextChanged_1(object sender, EventArgs e)
        {
            int.TryParse(t3.Text, out c1);
            loadoumark();
            /*
            if (!string.IsNullOrEmpty(t1.Text) && !string.IsNullOrEmpty(t2.Text) && !string.IsNullOrEmpty(t3.Text))
                label7.Text = (Convert.ToInt32(t1.Text) + Convert.ToInt32(t2.Text) + Convert.ToInt32(t3.Text)).ToString();
            else
            {
                label7.Text = null;
              
            }
             */
        }
        
       

        private void button1_Click(object sender, EventArgs e)
        {
             try
            {

                string sql = "INSERT INTO Marks(NameStudant,NameCourse,NameClass,NameGrade,Mark,MarkState,midtermexam,asepexam,finalexem) values (N'" + com1.Text + "',N'" + com2.Text + "',N'" + com4.Text + "',N'" + com3.Text + "',N'" + totalmark + "',N'" + state + "',N'" + t1.Text + "',N'" + t2.Text + "',N'" + t3.Text + "' ) ";
                con.Open();
                SqlCommand exeSql = new SqlCommand(sql, con);
                exeSql.ExecuteNonQuery();
                LoadMarksGV();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Enabled= false;
            LoadCourse();
            LoadStudent();
            LoadMarksGV();
            this.Enabled = true;
            timer1.Enabled = false;

        }

        private void com4_SelectedIndexChanged(object sender, EventArgs e)
        {
            timer1.Enabled = true;

        }

        private void com3_SelectedIndexChanged(object sender, EventArgs e)
        {
            timer1.Enabled = true;

        }

      

        }

    }

