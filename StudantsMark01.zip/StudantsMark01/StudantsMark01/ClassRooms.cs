﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudantsMark01
{
    public partial class ClassRooms : Form
    {
        public ClassRooms()
        {
            InitializeComponent();
        }

        private void ClassRooms_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.ClassRooms' table. You can move, or remove it, as needed.
            this.classRoomsTableAdapter.Fill(this.database1DataSet.ClassRooms);

        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.classRoomsBindingSource.EndEdit();
            this.classRoomsTableAdapter.Update(database1DataSet.ClassRooms);
            MessageBox.Show("تم الحفظ بنجاح");

        }
    }
}
