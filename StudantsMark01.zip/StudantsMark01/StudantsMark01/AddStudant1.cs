﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace StudantsMark01
{
    public partial class AddStudant1 : Form
    {

        String ss = "";
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);

        students std01;
        public AddStudant1(students std02)
        {
            InitializeComponent();
            this.std01 = std02;
        }

        private void AddStudant1_Load(object sender, EventArgs e)
        {
            loadcomb();
            try
            {
                con.Open();
                com2.Items.Clear();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = " select ctname from city ";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    com2.Items.Add(dr["ctname"].ToString());
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                con.Close();
            }
        }

        public void loadcomb() {

            SqlDataAdapter da = new SqlDataAdapter("select IDClassRooms,NameClassRooms from ClassRooms", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            com1.DisplayMember = "NameClassRooms";
            com1.ValueMember = "IDClassRooms";
            com1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             try
            {

                string sql = "INSERT INTO student(stide,stname,stadd,gender,IDClass) values ('" + t1.Text + "',N'" + t2.Text + "','" + com2.Text + "','" + ss + "',N'" + com1.SelectedValue + "' ) ";
                con.Open();
                SqlCommand exeSql = new SqlCommand(sql, con);
                exeSql.ExecuteNonQuery();

                MessageBox.Show("تم الاضافة بنجاح", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                std01.lodastudent();
                 this.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        
       

        private void c1_CheckedChanged(object sender, EventArgs e)
        {

            if (c1.Checked == true)
                ss = "Male";
        }

        private void c2_CheckedChanged(object sender, EventArgs e)
        {

            if (c2.Checked == true)
                ss = "Fmale";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
