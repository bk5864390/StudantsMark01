﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudantsMark01
{
    public partial class FormLogin : Form
    {
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        public FormLogin()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            da = new SqlDataAdapter("select * from login where Id ='" + user.Text + "' and pass='" + pass1.Text + "' ", con);
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                MainForm ff = new MainForm();
                
               ff.Show();
                this.Hide();

             
          
            }
            else
            {
                MessageBox.Show("يوجد خطأ فى تسجيل الدخول ");


            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

      

       
    }
}
