﻿namespace StudantsMark01 {
    
    
    public partial class Database1DataSet {
    }
}
