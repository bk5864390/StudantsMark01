﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace StudantsMark01
{
    public partial class AddCourse : Form
    {
        static SqlConnection con = new SqlConnection(global::StudantsMark01.Properties.Settings.Default.Database1ConnectionString);


        course dept;
        public AddCourse(course cdept)
        {
            InitializeComponent();
            this.dept = cdept;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string sql = "INSERT INTO course(CName,MinMark,MaxMark,IDClass) values (N'" + t2.Text + "','" + t3.Text + "','" + t4.Text + "' ,N'" + dept.com1.SelectedValue + "' ) ";
                con.Open();
                SqlCommand exeSql = new SqlCommand(sql, con);
                exeSql.ExecuteNonQuery();

                MessageBox.Show("تم الاضافة بنجاح", "message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dept.lodacourse();
                this.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void AddCourse_Load(object sender, EventArgs e)
        {

        }

      
    }
}
