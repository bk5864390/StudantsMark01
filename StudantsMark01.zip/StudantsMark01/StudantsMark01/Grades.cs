﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudantsMark01
{
    public partial class Grades : Form
    {
        public Grades()
        {
            InitializeComponent();
        }

        private void Grades_Load(object sender, EventArgs e)
        {
            this.gradesTableAdapter.Fill(this.database1DataSet.Grades);

        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.gradesBindingSource.EndEdit();
            this.gradesTableAdapter.Update(database1DataSet.Grades);
            MessageBox.Show("تم الحفظ بنجاح");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

      


    }
}
